/**
 *
 * @author 92E0988C1682C76D4D307AA15EC8346E
 */
public class T01 {
    public static void main(String[] args) {
        for (int i = 0; i < 5; i++) {
            System.out.println("Welcome To Java");
        }
    }
}
