
public class L6 {

    public static void print() {

        for (int i = 5; i > 0; i--) {
            System.out.print("Welcome to Java\n");
        }
    }

    public static void main(String[] args) {
        print();
    }
}
